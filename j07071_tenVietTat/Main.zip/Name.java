package j07071_tenVietTat;

public class Name implements Comparable<Name> {
    private String full, shortName;
    public Name(String full) {
        this.full = full;
        shortName = "";
        String[] tmp = full.split(" ");
        for (int i = 0; i < tmp.length; i++)
            this.shortName += tmp[i].charAt(0);
        shortName = shortName.toUpperCase();
    }

    public String getShortName() {
        return shortName;
    }

    @Override
    public String toString() {
        return full;
    }

    @Override
    public int compareTo(Name o) {
        String[] tmp = this.full.split(" ");
        String[] tmp2 = o.full.split(" ");
        if (tmp[tmp.length-1].compareTo(tmp2[tmp2.length-1])==0)
            return tmp[0].compareTo(tmp2[0]);
        else
            return tmp[tmp.length-1].compareTo(tmp2[tmp2.length-1]);
    }
}
