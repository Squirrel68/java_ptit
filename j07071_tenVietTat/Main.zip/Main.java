package j07071_tenVietTat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("DANHSACH.in"));
        int n = Integer.parseInt(sc.nextLine());
        ArrayList<Name> l = new ArrayList<>();
        while (n-->0)
            l.add(new Name(sc.nextLine()));
        Collections.sort(l);
        int q = Integer.parseInt(sc.nextLine());
        while (q-->0) {
            String s = sc.nextLine();
            String[] tmp = s.trim().split("\\.");
            int d = tmp.length;
            for (Name i : l){
                String sh = i.getShortName();
                String[] tmp1 = sh.split("");
                int ok = 1;
                for (int j = 0; j < d; j++) {
                    if (tmp[j].equals("*") || tmp[j].equals(tmp1[j]))
                        continue;
                    else {
                        ok = 0;
                        break;
                    }
                }
                if (ok == 1)
                    System.out.println(i);
            }

        }
    }
}
